from collections import OrderedDict

MAX = 8

def lru(paginas):
    memoria = OrderedDict()
    page_faults = 0

    for p in paginas:
        print(f"\npaginas: {p}")

        if p in memoria:
            print("deu hit, pagina ja esta na memoria")
            
            memoria.move_to_end(p)
        else:
            page_faults += 1
            if len(memoria) == MAX:
                
                removida = memoria.popitem(last=False)
                print(f"memoria estava cheia, pagina {removida} foi removida.")
            memoria[p] = True
            print(f"page fault, pagina {p} inserida.")

        print("Quadros atuais:", list(memoria.keys()))

    print("\ntotal de page faults:", page_faults, "\n\n")
    print("\n*****************************************\n")
    return page_faults


exercisio_a = [4,3,25,8,19,6,25,8,16,35,45,22,8,3,16,25,7] 
lru(exercisio_a)

exercisio_b = [4,5,7,9,46,45,14,4,64,7,65,2,1,6,8,45,14,11] 
lru(exercisio_b)

exercisio_c = [4,6,7,8,1,6,10,15,16,4,2,1,4,6,12,15,16,11] 
lru(exercisio_c)

