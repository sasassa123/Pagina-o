MAX = 8

def fifo(paginas):
    memoria = []
    page_faults = 0

    for p in paginas:
        print(f"\n paginas: {p}")

        if p in memoria:
            print("deu hit, pagina ja esta na memoria")
        else:
            page_faults += 1
            if len(memoria) == MAX:
                removida = memoria.pop(0)
                print(f"memoria estava cheia, pagina {removida} foi removida.")
            memoria.append(p)
            print(f"page fault, pagina {p} inserida.")

        print("Quadros atuais:", memoria)

    print("\ntotal de page faults:", page_faults, "\n\n")
    print("\n*****************************************\n")


exercisio_a = [4,3,25,8,19,6,25,8,16,35,45,22,8,3,16,25,7] #PF = 13, pagina 7 ta no ultimo quadro, oitavo
fifo(exercisio_a)

exercisio_b = [4,5,7,9,46,45,14,4,64,7,65,2,1,6,8,45,14,11] #PF = 14, pagina 11 ta no ultimo quadro, oitavo
fifo(exercisio_b)

exercisio_c = [4,6,7,8,1,6,10,15,16,4,2,1,4,6,12,15,16,11] #PF = 13, pagina 11 ta no ultimo quadro, oitavo
fifo(exercisio_c)

#FIFO: remove a pagina mais antiga adicionada na memoria

#QUESTAO 2: LRU é o algoritimo mais eficiente, pois se baseia nas paginas menos acessadas para remove-las, verificando a ultima acessada nos quadros para substitui-la, 
# fifo apenas remove a pagina mais antiga colocada nos quadros,
# e o MRU remove as paginas mais recentes acessadas o contrario do LRU, por consequencia sendo o mais ineficiente em geral do que os outros, algoritimo aplicado geralmente para tratamento de dados variaveis
#porem nesse caso o algoritimo mais eficiente foi o MRU, apesar do algoritimo nao ser tao eficiente para este caso ele foi o melhor em otimização

#grupo: Pietro de Souza Mastantuono, Felippe Matias Cardinot, Joao Cracco